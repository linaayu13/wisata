<div class="nav-collapse nav-collapse_ collapse">
                    <ul class="nav sf-menu clearfix">
                        <li class="active"><a href="<?php  echo base_url().''?>" class="">Home</a></li>
                        <li class="sub-menu sub-menu-1"><a href="#">Profil <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul>
                                <li><a href="<?php echo base_url().'about';?>"><span>&nbsp;&nbsp;&nbsp;- </span>Tentang Kami</a></li>
                                <li><a href="<?php echo base_url().'testimoni';?>"><span>&nbsp;&nbsp;&nbsp;- </span>Testimoni</a></li>
                                <li><a href="<?php echo base_url().'lokasi';?>"><span>&nbsp;&nbsp;&nbsp;- </span>Lokasi</a></li>
                            </ul>
                        <li><a href="<?php echo base_url().'wisata_post'?>">Wisata</a></li>
                        <li><a href="<?php echo base_url().'berita_post'?>">Berita</a></li>
                        <li class="sub-menu sub-menu-1"><a href="#">Gallery <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                            <ul>
                                <li><a href="<?php echo base_url().'semua_album';?>"><span>&nbsp;&nbsp;&nbsp;- </span>Album Photo</a></li>
                                <li><a href="<?php echo base_url().'detail_photo/galeri';?>"><span>&nbsp;&nbsp;&nbsp;- </span>Gallery Photo</a></li>
                            </ul>
                        </li>


                        
                        <li> <a href="<?php echo base_url().'kontak'?>">Hubungi Kami</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>  
</div>